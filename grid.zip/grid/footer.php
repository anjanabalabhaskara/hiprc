<?php
echo '
    

    <div id="global_footer">
    <footer>
        <div class="container">
            <div class="row">

                <div class="col-md-3 col-sm-4"  >
                    <h3>Useful Links</h3>
                    <p><a href="#">Courses</a></p>
                    <p><a href="#"></a></p>
                    <p><a href="#"></a></p>
                    <p><a href="#"></a></p>
                </div>
            
                <div class="col-md-5 col-sm-4 newsletter">
                    <h3>PI</h3>
                    <p>Dr.Soumyajit Dey</p>
                    <div class="input-group">
                        <p> Associate Professor</p>
                        <p> Department of Computer Science and Engineering </p>
                        <p> Indian Instituted of Technology, Kharagpur </p>

                     </div>
                </div>

                <div class="col-md-4 col-sm-4">
                    <img src="../images/logo.pdf" class="img-responsive" alt="logo">
                    <p>HiPRC or High Performance Real-time Computation Lab is a reserach lab in IIT Kharagpur.
                    
                    </p>
                    <p><i class="fa fa-phone"></i> 000000</p>
                    <p><i class="fa fa-envelope-o"></i> ****@iitkgp.ac.in</p>
                  <p><i class="fa fa-globe"></i> www.facebook.com</p>
                </div>

            
                
                
                
            </div>
        </div>
    </footer>


    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <p>Copyright © ******</p>
                </div>
                <div class="col-md-6 col-sm-6">
                    <ul class="social-icons">
                        <li><a href="#" class="fa fa-facebook"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-dribbble"></a></li>
                        <li><a href="#" class="fa fa-pinterest"></a></li>
                        <li><a href="#" class="fa fa-behance"></a></li>
                        <li><a href="#" class="fa fa-envelope-o"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    </div>
    
    ';
?>

