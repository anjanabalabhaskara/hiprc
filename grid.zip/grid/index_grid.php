<!DOCTYPE html>
<html lang="en">

<!-- header section -->
<?php include 'header.php';?>

<body>
	
<!-- navigation -->

	<div class="container">
		<div class="navbar navbar-default navbar-static-top" role="navigation">
		<div class="navbar-header">
			<a href="#" class="navbar-brand"><img src="/grid/images/hiprc2.png " width="115" border="0" class="img-responsive"  alt="logo"></a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="../index.php">HOME</a></li>
				<li><a href="about.php">PEOPLE</a></li>
				<li><a href="projects.php">PROJECTS</a></li>
				<li><a href="tools.php">TOOLS</a></li>
				<li><a href="../contact.php">CONTACT US</a></li>
			</ul>
		</div>
	</div>
</div>		


	<div class="container text-center rounded_rectangle">
		<div class="row" style="padding:15px">
			<!-- <div class="col-md-12 col-sm-12"> -->
			<div class="hero-unit">
				<h1><span>Smart Grid</span></h1>
			</div>
			<!-- </div> -->
		</div>
		<div class="row" style="padding:15px">
			<img class="img-responsive" src="/grid/images/Grid.jpg" alt="cpsbanner">
		</div>
		<div class="row topic-desc lead" style="padding:15px">
			<p><span>
				</span></p>
		</div>
		<br>
			<hr class="divider-line">
	</div>


<!-- divider section -->

<div class="divider">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<div class="divider-wrapper divider-one">
					<i class="fa fa-laptop"></i>
					<h2>Smart Grid Design Tool</h2>
					<p></p>
					<a href="smartgrid_Tool.php" class="btn btn-default">LEARN MORE</a>
					<p> </p>
				</div>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="divider-wrapper divider-two">
					<i class="fa fa-laptop"></i>
					<h2>Intelligent Building Energy system</h2>
					<p> </p>
					<a href="BEMS.php" class="btn btn-default">LEARN MORE</a>
					<p> </p>
				</div>
			</div>

		</div>
	</div>
</div>
<div class="divider">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<div class="divider-wrapper divider-one">
					<i class="fa fa-laptop"></i>
					<h2>Smart Grid Privacy</h2>
					<p> </p>
					<a href="Privacy.php" class="btn btn-default">LEARN MORE</a>
					<p> </p>
				</div>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="divider-wrapper divider-two">
					<i class="fa fa-laptop"></i>
					<h2>CAD for HVAC Automation</h2>
					<p> </p>
					<a href="HVAC.php" class="btn btn-default">LEARN MORE</a>
					<p> </p>
				</div>
			</div>

		</div>
	</div>
</div>

<!-- about section -->
<div id="about">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4" >
				<img src="../grid/images/Resources.jpg" class="img-responsive" alt="about img" style="padding-top: 50px;">
			</div>
			<div class="col-md-8 col-sm-12 about-des">
				<h2>Resources</h2>
				<p></p>
				<p></p>
				<a href="about.php" class="btn btn-default">LEARN MORE</a>
			</div>
		</div>
	</div>
</div>
		
	

<!-- footer section -->
<?php include 'footer.php';?>

<!-- javascript js -->	
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>	
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>
