<!DOCTYPE html>
<html lang="en">

<!-- header section -->
<?php include 'header.php';?>

<body>
	
<!-- navigation -->

	<div class="container">
		<div class="navbar navbar-default navbar-static-top" role="navigation">
		<div class="navbar-header">
			<a href="#" class="navbar-brand"><img src="/images/hiprc2.png " width="115" border="0" class="img-responsive"  alt="logo"></a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="../index.php">HOME</a></li>
				<li><a href="about.php">PEOPLE</a></li>
				<li><a href="projects.php">PROJECTS</a></li>
				<li><a href="tools.php">TOOLS</a></li>
				<li><a href="../contact.php">CONTACT US</a></li>
			</ul>
		</div>
	</div>
</div>			



	<div class="container text-center rounded_rectangle">
		<div class="row" style="padding:15px">
			<!-- <div class="col-md-12 col-sm-12"> -->
			<div class="hero-unit">
				<h1><span>  A Software Tool for the Planning and Design of Smart Grids</span></h1>
			</div>
			<!-- </div> -->
		</div>
		<div class="row" style="padding:15px">
			<img class="one" src="/grid/images/Tool_flow.png" width="700" height="400" alt="HVAC">
		</div>
		<div class="row topic-desc" style="padding:15px">
			<p><span>

			This work is related to developing a tool for the designing microgrid. This software tool provides high-level guidance to users for selecting grid configuration (essentially the bus architecture), load specification, Distributed Energy Resources (DERs) specification etc. The overall Frontend and Initial Specification Environment of this tool can be divided mainly into two parts: The user specifies the load details and total power to be generated. The tool also provides Microgrid Architecture and Control Strategy selection scope.

This tool also provides a microgrid design from high level design specification with automatic initial design generation and scheduling optimizations for various types of building loads. 


				</span></p>
		</div>
		<br>
			<hr class="divider-line">
	</div>
								

<!-- footer section -->
<?php include 'footer.php';?>

<!-- javascript js -->	
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>	
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>
