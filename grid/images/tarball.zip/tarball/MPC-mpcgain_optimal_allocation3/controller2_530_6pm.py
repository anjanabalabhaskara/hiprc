import matlab.engine
eng = matlab.engine.connect_matlab('rajib')

import os
# Fetch the current directory path
current_dir_Path = os.getcwd()

in_file = open(current_dir_Path+"/MPC-mpcgain_optimal_allocation3/input2.txt","r")
lines = in_file.readlines()
in_file.close()
output = []
value = []


for line in lines:
	line=line.lstrip()
	elements = line.split("\n")
	value.append(elements)
	
		
TW1=float(value[0][0])
TW2=float(value[1][0])
TW3=float(value[2][0])
TW4=float(value[3][0])
TW5=float(value[4][0])
TW6=float(value[5][0])
TW7=float(value[6][0])
TW8=float(value[7][0])
TW9=float(value[8][0])
TW10=float(value[9][0])
TW11=float(value[10][0])
TW12=float(value[11][0])
TW13=float(value[12][0])
TW14=float(value[13][0])
TW15=float(value[14][0])
TW16=float(value[15][0])
TW17=float(value[16][0])
TW18=float(value[17][0])
TW19=float(value[18][0])
TW20=float(value[19][0])
TW21=float(value[20][0])
TW22=float(value[21][0])
TR1=float(value[22][0])+273.15
TR2=float(value[23][0])+273.15
TR3=float(value[24][0])+273.15
TR4=float(value[25][0])+273.15
TR5=float(value[26][0])+273.15
TR6=float(value[27][0])+273.15
TR7=float(value[28][0])+273.15
u1=float(value[29][0])
u2=float(value[30][0])
u3=float(value[31][0])
u4=float(value[32][0])
u5=float(value[33][0])
u6=float(value[34][0])
u7=float(value[35][0])	
dTR1=float(value[36][0])
dTR2=float(value[37][0])
dTR3=float(value[38][0])
dTR4=float(value[39][0])
dTR5=float(value[40][0])
dTR6=float(value[41][0])
dTR7=float(value[42][0])

u1, u2, u3, u4, u5, u6, u7=eng.controller2_530_6pm(TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,u1,u2,u3,u4,u5,u6,u7,dTR1,dTR2,dTR3,dTR4,dTR5,dTR6,dTR7,nargout=7)

output.append(str(u1))
output.append("\n")
output.append(str(u2))
output.append("\n")
output.append(str(u3))
output.append("\n")
output.append(str(u4))
output.append("\n")
output.append(str(u5))
output.append("\n")
output.append(str(u6))
output.append("\n")
output.append(str(u7))

outfile = open(current_dir_Path+"/MPC-mpcgain_optimal_allocation3/output2.txt", "w")
for line in output:
	outfile.write(line)
outfile.close()	

