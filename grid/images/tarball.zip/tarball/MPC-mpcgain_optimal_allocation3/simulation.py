import numpy as np
from OMPython import ModelicaSystem
import os
import matplotlib.pyplot as plt

d = {} # For controller 1
d2 = {} # For controller 2
value = []
output = []
target = []

Data_RMSE_TR13=[]
Data_RMSE_TR33=[]
Data_RMSE_TR53=[]
Data_RMSE_TR73=[]

# Initial values of plant for controller 1
d["TW1"] = str(303.15)
d["TW2"] = str(303.15)
d["TW3"] = str(303.15)
d["TW4"] = str(303.15)
d["TW5"] = str(303.15)
d["TW6"] = str(303.15)
d["TW7"] = str(303.15)
d["TW8"] = str(303.15)
d["TW9"] = str(303.15)
d["TW10"] = str(303.15)
d["TW11"] = str(303.15)
d["TW12"] = str(303.15)
d["TW13"] = str(303.15)
d["TW14"] = str(303.15)
d["TW15"] = str(303.15)
d["TW16"] = str(303.15)
d["TW17"] = str(303.15)
d["TW18"] = str(303.15)
d["TW19"] = str(303.15)
d["TW20"] = str(303.15)
d["TW21"] = str(303.15)
d["TW22"] = str(303.15)
d["TR1"] = str(303.15-273.15)
d["TR2"] = str(303.15-273.15)
d["TR3"] = str(303.15-273.15)
d["TR4"] = str(303.15-273.15)
d["TR5"] = str(303.15-273.15)
d["TR6"] = str(303.15-273.15)
d["TR7"] = str(303.15-273.15)

d["u1"] = str(0)
d["u2"] = str(0)
d["u3"] = str(0)
d["u4"] = str(0)
d["u5"] = str(0)
d["u6"] = str(0)
d["u7"] = str(0)

d["pE"] = str(0)

# Generating input.txt file for controller.py
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0)) 
target.append("\n")
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(d["TR1"] ))
target.append("\n")
target.append(str(d["TR2"] ))
target.append("\n")
target.append(str(d["TR3"] ))
target.append("\n")
target.append(str(d["TR4"] ))
target.append("\n")
target.append(str(d["TR5"] ))
target.append("\n")
target.append(str(d["TR6"] ))
target.append("\n")
target.append(str(d["TR7"] ))
target.append("\n")
target.append(str(d["u1"] ))
target.append("\n")
target.append(str(d["u2"] ))
target.append("\n")
target.append(str(d["u3"] ))
target.append("\n")
target.append(str(d["u4"] ))
target.append("\n")
target.append(str(d["u5"] ))
target.append("\n")
target.append(str(d["u6"] ))
target.append("\n")
target.append(str(d["u7"]))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))


outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
for line in target:
	outfile.write(line)
outfile.close()	

target[:]=[]

# Initial values of plant for controller 2
d2["TW1"] = str(303.15)
d2["TW2"] = str(303.15)
d2["TW3"] = str(303.15)
d2["TW4"] = str(303.15)
d2["TW5"] = str(303.15)
d2["TW6"] = str(303.15)
d2["TW7"] = str(303.15)
d2["TW8"] = str(303.15)
d2["TW9"] = str(303.15)
d2["TW10"] = str(303.15)
d2["TW11"] = str(303.15)
d2["TW12"] = str(303.15)
d2["TW13"] = str(303.15)
d2["TW14"] = str(303.15)
d2["TW15"] = str(303.15)
d2["TW16"] = str(303.15)
d2["TW17"] = str(303.15)
d2["TW18"] = str(303.15)
d2["TW19"] = str(303.15)
d2["TW20"] = str(303.15)
d2["TW21"] = str(303.15)
d2["TW22"] = str(303.15)
d2["TR11"] = str(303.15-273.15)
d2["TR12"] = str(303.15-273.15)
d2["TR13"] = str(303.15-273.15)
d2["TR14"] = str(303.15-273.15)
d2["TR15"] = str(303.15-273.15)
d2["TR16"] = str(303.15-273.15)
d2["TR17"] = str(303.15-273.15)

d2["u11"] = str(0)
d2["u12"] = str(0)
d2["u13"] = str(0)
d2["u14"] = str(0)
d2["u15"] = str(0)
d2["u16"] = str(0)
d2["u17"] = str(0)



# Generating input2.txt file for controller2.py
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0)) 
target.append("\n")
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(0))
target.append("\n")
target.append(str(d2["TR11"] ))
target.append("\n")
target.append(str(d2["TR12"] ))
target.append("\n")
target.append(str(d2["TR13"] ))
target.append("\n")
target.append(str(d2["TR14"] ))
target.append("\n")
target.append(str(d2["TR15"] ))
target.append("\n")
target.append(str(d2["TR16"] ))
target.append("\n")
target.append(str(d2["TR17"] ))
target.append("\n")
target.append(str(d2["u11"] ))
target.append("\n")
target.append(str(d2["u12"] ))
target.append("\n")
target.append(str(d2["u13"] ))
target.append("\n")
target.append(str(d2["u14"] ))
target.append("\n")
target.append(str(d2["u15"] ))
target.append("\n")
target.append(str(d2["u16"] ))
target.append("\n")
target.append(str(d2["u17"]))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))
target.append("\n") 
target.append(str(0))


outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
for line in target:
	outfile.write(line)
outfile.close()	

target[:]=[]



for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_8_830am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_8_830am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_8_830am.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_8_830am.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_8_830am.mo","simulation_8_830am.time_8_830am",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600, stopTime=kk*600+600)
	mod.simulate()

	# Saving data for generating graph@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	if kk == 0:
		Data_time, Data_TR1, RMSE_TR1, RMSE_TR3, RMSE_TR5,RMSE_TR7, Data_Total_Energy,Data_r1_flow=mod.getSolutions(["time", "myfloor1.TR1", "myfloor1.TR1", "myfloor1.TR3", "myfloor1.TR5","myfloor1.TR7", "Total_Energy.y","in_r1.m_flow_in"])
	else:
		Data_time=np.append(Data_time, mod.getSolutions("time"))
		Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
		Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
		Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 830_9am
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MPC3 Simulation for 830_9am @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_830_9am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_830_9am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_830_9am.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_830_9am.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_830_9am.mo","simulation_830_9am.time_830_9am",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+1800, stopTime=kk*600+600+1800)
	mod.simulate()

	# Saving data for graph 
	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
	RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
	RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))
	RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))


		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)


#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)

	

# Simulation for 9_930am
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MPC 3 Simulation for 9_930am @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_9_930am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_9_930am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_9_930am.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_9_930am.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_9_930am.mo","simulation_9_930am.time_9_930am",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+3600, stopTime=kk*600+600+3600)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR1, RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 930_10am
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 930_10am @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_930_10am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_930_10am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_930_10am.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_930_10am.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_930_10am.mo","simulation_930_10am.time_930_10am",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+5400, stopTime=kk*600+600+5400)
	mod.simulate()

	# Saving data for graph 
	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
	RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
	RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))	

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	
# RMSE calculation
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

Data_RMSE_TR7.append(0)

# Simulation for 10_1030am
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 10_1030am @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_10_1030am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_10_1030am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_10_1030am.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_10_1030am.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_10_1030am.mo","simulation_10_1030am.time_10_1030am",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+7200, stopTime=kk*600+600+7200)
	mod.simulate()

	# Saving data for generating graph@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	if kk == 0:
		RMSE_TR1, RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	


# Simulation for 1030_11am
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 1030_11am @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_1030_11am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_1030_11am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1030_11am.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1030_11am.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1030_11am.mo","simulation_1030_11am.time_1030_11am",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+9000, stopTime=kk*600+600+9000)
	mod.simulate()

	# Saving data for graph 
	if kk==0:
		RMSE_TR7=mod.getSolutions("myfloor1.TR7")
	else:
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
	RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
	RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	


# Simulation for 11_1130am
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 11_1130am @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_11_1130am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_11_1130am.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_11_1130am.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_11_1130am.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_11_1130am.mo","simulation_11_1130am.time_11_1130am",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+10800, stopTime=kk*600+600+10800)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR1, RMSE_TR7=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR7"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))


	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 1130_12noon
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 1130_12noon @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_1130_12noon.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_1130_12noon.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1130_12noon.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1130_12noon.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1130_12noon.mo","simulation_1130_12noon.time_1130_12noon",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+12600, stopTime=kk*600+600+12600)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
	RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	

# Simulation for 12_1230pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 12_1230pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_12_1230pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_12_1230pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_12_1230pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_12_1230pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_12_1230pm.mo","simulation_12_1230pm.time_12_1230pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+14400, stopTime=kk*600+600+14400)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR7,RMSE_TR1, RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR7", "myfloor1.TR1","myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 1230_2pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 1230_2pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(9):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_1230_2pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_1230_2pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1230_2pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1230_2pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_1230_2pm.mo","simulation_1230_2pm.time_1230_2pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+16200, stopTime=kk*600+600+16200)
	mod.simulate()

	# Saving data for graph 
	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))	
	RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
	RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))


		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math

no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	

# Simulation for 2_3pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MPC3 Simulation for 2_3pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(6):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_2_3pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_2_3pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_2_3pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_2_3pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_2_3pm.mo","simulation_2_3pm.time_2_3pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+21600, stopTime=kk*600+600+21600)
	mod.simulate()

	# Saving data for graph 
	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

# RMSE calculation	
Data_RMSE_TR1.append(0)
Data_RMSE_TR3.append(0)
Data_RMSE_TR5.append(0)
Data_RMSE_TR7.append(0)	

# Simulation for 3_330pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 3_330pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_3_330pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_3_330pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_3_330pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_3_330pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_3_330pm.mo","simulation_3_330pm.time_3_330pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+25200, stopTime=kk*600+600+25200)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR1, RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 330_4pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 330_4pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_330_4pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_330_4pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_330_4pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_330_4pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_330_4pm.mo","simulation_330_4pm.time_330_4pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+27000, stopTime=kk*600+600+27000)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR7=mod.getSolutions(["myfloor1.TR7"])

		
	else:
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))
		

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
	RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
	RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	

# Simulation for 4_430pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 4_430pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_4_430pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_4_430pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_4_430pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_4_430pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_4_430pm.mo","simulation_4_430pm.time_4_430pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+28800, stopTime=kk*600+600+28800)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR1, RMSE_TR7=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR7"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))


		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 430_5pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 430_5pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_430_5pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_430_5pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_430_5pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_430_5pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_430_5pm.mo","simulation_430_5pm.time_430_5pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+30600, stopTime=kk*600+600+30600)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
	RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	

# Simulation for 5_530pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 5_530pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_5_530pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_5_530pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_5_530pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_5_530pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_5_530pm.mo","simulation_5_530pm.time_5_530pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+32400, stopTime=kk*600+600+32400)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR7,RMSE_TR1, RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR7", "myfloor1.TR1","myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 530_6pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 530_6pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_530_6pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_530_6pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_530_6pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_530_6pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_530_6pm.mo","simulation_530_6pm.time_530_6pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+34200, stopTime=kk*600+600+34200)
	mod.simulate()

	# Saving data for graph 
	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math

no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	

# Simulation for 6_630pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MPC 3 Simulation for 6_630pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_6_630pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_6_630pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_6_630pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_6_630pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_6_630pm.mo","simulation_6_630pm.time_6_630pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+36000, stopTime=kk*600+600+36000)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR1, RMSE_TR3, RMSE_TR5=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR3", "myfloor1.TR5"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 630_7pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 630_7pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_630_7pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_630_7pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_630_7pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_630_7pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_630_7pm.mo","simulation_630_7pm.time_630_7pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+37800, stopTime=kk*600+600+37800)
	mod.simulate()

	# Saving data for graph 
	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))

	RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
	RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
	RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)

no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

Data_RMSE_TR7.append(0)	

# Simulation for 7_730pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Simulation for 7_730pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(3):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_7_730pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_7_730pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_7_730pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_7_730pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_7_730pm.mo","simulation_7_730pm.time_7_730pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+39600, stopTime=kk*600+600+39600)
	mod.simulate()

	# Saving data for graph 
	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))


		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

	

# Simulation for 730_830pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MPC3 Simulation for 730_830pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(6):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_730_830pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_730_830pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_730_830pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_730_830pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_730_830pm.mo","simulation_730_830pm.time_730_830pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+41400, stopTime=kk*600+600+41400)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR1, RMSE_TR3, RMSE_TR5, RMSE_TR7=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR3", "myfloor1.TR5", "myfloor1.TR7"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))
		

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)


no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	

# Simulation for 830_930pm
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MPC3 Simulation for 830_930pm @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
for kk in range(6):
	# For controller 1
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller1_830_930pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d["u1"] = str(value[0][0])
	d["u2"] = str(value[1][0])
	d["u3"] = str(value[2][0])
	d["u4"] = str(value[3][0])
	d["u5"] = str(value[4][0])
	d["u6"] = str(value[5][0])
	d["u7"] = str(value[6][0])

	value[:]=[]

	# For controller 2
	os.system('python /home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/controller2_830_930pm.py')
	in_file = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/output2.txt","r")
	lines = in_file.readlines()
	in_file.close()
	
	

	for line in lines:
		line=line.lstrip()
		elements = line.split("\n")
		value.append(elements)

	d2["u11"] = str(value[0][0])
	d2["u12"] = str(value[1][0])
	d2["u13"] = str(value[2][0])
	d2["u14"] = str(value[3][0])
	d2["u15"] = str(value[4][0])
	d2["u16"] = str(value[5][0])
	d2["u17"] = str(value[6][0])

	value[:]=[]


	mofile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_830_930pm.mo","r")
	lines = mofile.readlines()
	mofile.close()
	

	for line in lines:
		lines=line.lstrip()
		elements = lines.split(" ")
		if elements[0] == "parameter":
			var = elements[2]
			if var in d.keys():
				elements[4] = d[var]
			if var in d2.keys():
				elements[4] = d2[var]
			
		output_string = " ".join(elements)
		output.append(output_string)

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_830_930pm.mo", "w")
	for line in output:
		outfile.write(line)
	outfile.close()

	output[:]=[]

	mod=ModelicaSystem("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/simulation_830_930pm.mo","simulation_830_930pm.time_830_930pm",["Modelica","Buildings"])
	mod.setSimulationOptions(startTime=kk*600+45000, stopTime=kk*600+600+45000)
	mod.simulate()

	# Saving data for graph 
	if kk == 0:
		RMSE_TR1, RMSE_TR3, RMSE_TR5, RMSE_TR7=mod.getSolutions(["myfloor1.TR1", "myfloor1.TR3", "myfloor1.TR5", "myfloor1.TR7"])

		
	else:
		RMSE_TR1=np.append(RMSE_TR1, mod.getSolutions("myfloor1.TR1"))
		RMSE_TR3=np.append(RMSE_TR3, mod.getSolutions("myfloor1.TR3"))
		RMSE_TR5=np.append(RMSE_TR5, mod.getSolutions("myfloor1.TR5"))
		RMSE_TR7=np.append(RMSE_TR7, mod.getSolutions("myfloor1.TR7"))

	Data_time=np.append(Data_time, mod.getSolutions("time"))
	Data_TR1=np.append(Data_TR1, mod.getSolutions("myfloor1.TR1"))
	Data_r1_flow=np.append(Data_r1_flow, mod.getSolutions("in_r1.m_flow_in"))
	Data_Total_Energy=np.append(Data_Total_Energy, mod.getSolutions("Total_Energy.y"))
		
	
	# For controller 1 (floor 1)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7,pE =mod.getSolutions(["myfloor1.TW1", "myfloor1.TW2", "myfloor1.TW3", "myfloor1.TW4","myfloor1.TW5","myfloor1.TW6","myfloor1.TW7","myfloor1.TW8","myfloor1.TW9","myfloor1.TW10","myfloor1.TW11","myfloor1.TW12","myfloor1.TW13","myfloor1.TW14","myfloor1.TW15","myfloor1.TW16","myfloor1.TW17","myfloor1.TW18","myfloor1.TW19","myfloor1.TW20","myfloor1.TW21","myfloor1.TW22","myfloor1.TR1","myfloor1.TR2","myfloor1.TR3","myfloor1.TR4","myfloor1.TR5","myfloor1.TR6","myfloor1.TR7","Total_Energy.y"])

	target.append(str(TW1[-1]-float(d["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d["u1"] ))
	target.append("\n")
	target.append(str(d["u2"] ))
	target.append("\n")
	target.append(str(d["u3"] ))
	target.append("\n")
	target.append(str(d["u4"] ))
	target.append("\n")
	target.append(str(d["u5"] ))
	target.append("\n")
	target.append(str(d["u6"] ))
	target.append("\n")
	target.append(str(d["u7"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d["TR1"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d["TR2"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d["TR3"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d["TR4"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d["TR5"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d["TR6"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d["TR7"] )-273.15))


	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d["TW1"] = str(TW1[-1])
	d["TW2"] = str(TW2[-1])
	d["TW3"] = str(TW3[-1])
	d["TW4"] = str(TW4[-1])
	d["TW5"] = str(TW5[-1])
	d["TW6"] = str(TW6[-1])
	d["TW7"] = str(TW7[-1])
	d["TW8"] = str(TW8[-1])
	d["TW9"] = str(TW9[-1])
	d["TW10"] = str(TW10[-1])
	d["TW11"] = str(TW11[-1])
	d["TW12"] = str(TW12[-1])
	d["TW13"] = str(TW13[-1])
	d["TW14"] = str(TW14[-1])
	d["TW15"] = str(TW15[-1])
	d["TW16"] = str(TW16[-1])
	d["TW17"] = str(TW17[-1])
	d["TW18"] = str(TW18[-1])
	d["TW19"] = str(TW19[-1])
	d["TW20"] = str(TW20[-1])
	d["TW21"] = str(TW21[-1])
	d["TW22"] = str(TW22[-1])
	d["TR1"] = str(TR1[-1] - 273.15)
	d["TR2"] = str(TR2[-1] - 273.15)
	d["TR3"] = str(TR3[-1] - 273.15)
	d["TR4"] = str(TR4[-1] - 273.15)
	d["TR5"] = str(TR5[-1] - 273.15)
	d["TR6"] = str(TR6[-1] - 273.15)
	d["TR7"] = str(TR7[-1] - 273.15)

	d["pE"] = str(pE[-1])

	

	
	# For controller 2 (floor 2)
	TW1,TW2,TW3,TW4,TW5,TW6,TW7,TW8,TW9,TW10,TW11,TW12,TW13,TW14,TW15,TW16,TW17,TW18,TW19,TW20,TW21,TW22,TR1,TR2,TR3,TR4,TR5,TR6,TR7=mod.getSolutions(["myfloor2.TW1", "myfloor2.TW2", "myfloor2.TW3", "myfloor2.TW4","myfloor2.TW5","myfloor2.TW6","myfloor2.TW7","myfloor2.TW8","myfloor2.TW9","myfloor2.TW10","myfloor2.TW11","myfloor2.TW12","myfloor2.TW13","myfloor2.TW14","myfloor2.TW15","myfloor2.TW16","myfloor2.TW17","myfloor2.TW18","myfloor2.TW19","myfloor2.TW20","myfloor2.TW21","myfloor2.TW22","myfloor2.TR1","myfloor2.TR2","myfloor2.TR3","myfloor2.TR4","myfloor2.TR5","myfloor2.TR6","myfloor2.TR7"])

	target.append(str(TW1[-1]-float(d2["TW1"])))
	target.append("\n") 
	target.append(str(TW2[-1]-float(d2["TW2"])))
	target.append("\n")
	target.append(str(TW3[-1]-float(d2["TW3"])))
	target.append("\n")
	target.append(str(TW4[-1]-float(d2["TW4"])))
	target.append("\n")
	target.append(str(TW5[-1]-float(d2["TW5"])))
	target.append("\n")
	target.append(str(TW6[-1]-float(d2["TW6"])))
	target.append("\n") 
	target.append(str(TW7[-1]-float(d2["TW7"])))
	target.append("\n") 
	target.append(str(TW8[-1]-float(d2["TW8"]))) 
	target.append("\n")
	target.append(str(TW9[-1]-float(d2["TW9"])))
	target.append("\n") 
	target.append(str(TW10[-1]-float(d2["TW10"])))
	target.append("\n") 
	target.append(str(TW11[-1]-float(d2["TW11"])))
	target.append("\n")
	target.append(str(TW12[-1]-float(d2["TW12"])))
	target.append("\n")
	target.append(str(TW13[-1]-float(d2["TW13"])))
	target.append("\n")
	target.append(str(TW14[-1]-float(d2["TW14"])))
	target.append("\n")
	target.append(str(TW15[-1]-float(d2["TW15"])))
	target.append("\n")
	target.append(str(TW16[-1]-float(d2["TW16"])))
	target.append("\n")
	target.append(str(TW17[-1]-float(d2["TW17"])))
	target.append("\n")
	target.append(str(TW18[-1]-float(d2["TW18"])))
	target.append("\n")
	target.append(str(TW19[-1]-float(d2["TW19"])))
	target.append("\n")
	target.append(str(TW20[-1]-float(d2["TW20"])))
	target.append("\n")
	target.append(str(TW21[-1]-float(d2["TW21"])))
	target.append("\n")
	target.append(str(TW22[-1]-float(d2["TW22"])))
	target.append("\n")
	target.append(str(TR1[-1] - 273.15))
	target.append("\n")
	target.append(str(TR2[-1] - 273.15))
	target.append("\n")
	target.append(str(TR3[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR4[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR5[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR6[-1] - 273.15 ))
	target.append("\n")
	target.append(str(TR7[-1] - 273.15 ))
	target.append("\n")
	target.append(str(d2["u11"] ))
	target.append("\n")
	target.append(str(d2["u12"] ))
	target.append("\n")
	target.append(str(d2["u13"] ))
	target.append("\n")
	target.append(str(d2["u14"] ))
	target.append("\n")
	target.append(str(d2["u15"] ))
	target.append("\n")
	target.append(str(d2["u16"] ))
	target.append("\n")
	target.append(str(d2["u17"]))
	target.append("\n")
	target.append(str(TR1[-1]-float(d2["TR11"] )-273.15))
	target.append("\n")
	target.append(str(TR2[-1]-float(d2["TR12"] )-273.15))
	target.append("\n")
	target.append(str(TR3[-1]-float(d2["TR13"] )-273.15))
	target.append("\n")
	target.append(str(TR4[-1]-float(d2["TR14"] )-273.15))
	target.append("\n")
	target.append(str(TR5[-1]-float(d2["TR15"] )-273.15))
	target.append("\n")
	target.append(str(TR6[-1]-float(d2["TR16"] )-273.15))
	target.append("\n")
	target.append(str(TR7[-1]-float(d2["TR17"] )-273.15))

	outfile = open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/MPC-mpcgain_optimal_allocation3/input2.txt", "w")
	for line in target:
		outfile.write(line)
	outfile.close()	

	target[:]=[]


	d2["TW1"] = str(TW1[-1])
	d2["TW2"] = str(TW2[-1])
	d2["TW3"] = str(TW3[-1])
	d2["TW4"] = str(TW4[-1])
	d2["TW5"] = str(TW5[-1])
	d2["TW6"] = str(TW6[-1])
	d2["TW7"] = str(TW7[-1])
	d2["TW8"] = str(TW8[-1])
	d2["TW9"] = str(TW9[-1])
	d2["TW10"] = str(TW10[-1])
	d2["TW11"] = str(TW11[-1])
	d2["TW12"] = str(TW12[-1])
	d2["TW13"] = str(TW13[-1])
	d2["TW14"] = str(TW14[-1])
	d2["TW15"] = str(TW15[-1])
	d2["TW16"] = str(TW16[-1])
	d2["TW17"] = str(TW17[-1])
	d2["TW18"] = str(TW18[-1])
	d2["TW19"] = str(TW19[-1])
	d2["TW20"] = str(TW20[-1])
	d2["TW21"] = str(TW21[-1])
	d2["TW22"] = str(TW22[-1])
	d2["TR11"] = str(TR1[-1] - 273.15)
	d2["TR12"] = str(TR2[-1] - 273.15)
	d2["TR13"] = str(TR3[-1] - 273.15)
	d2["TR14"] = str(TR4[-1] - 273.15)
	d2["TR15"] = str(TR5[-1] - 273.15)
	d2["TR16"] = str(TR6[-1] - 273.15)
	d2["TR17"] = str(TR7[-1] - 273.15)

#Calculating RMSE
import math
no_sample = len(RMSE_TR1)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR1[i]))*(295.15 - float(RMSE_TR1[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR1.append(sumation)

no_sample = len(RMSE_TR3)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR3[i]))*(295.15 - float(RMSE_TR3[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR3.append(sumation)


no_sample = len(RMSE_TR5)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR5[i]))*(295.15 - float(RMSE_TR5[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR5.append(sumation)

no_sample = len(RMSE_TR7)
sumation=0
for i in range(no_sample):
	sumation=sumation + (295.15 - float(RMSE_TR7[i]))*(295.15 - float(RMSE_TR7[i]))
sumation=sumation/no_sample
sumation=math.sqrt(sumation)
Data_RMSE_TR7.append(sumation)	


print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ MPC-3 Simulation Complete @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")


with open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/RESULT/3_MPC-Data_time.txt", "w") as datafile:  
    for listitem in Data_time:
        datafile.write('%s\n' % listitem)
datafile.close()


with open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/RESULT/3_MPC-Data_Total_Energy.txt", "w") as datafile:  
    for listitem in Data_Total_Energy:
        datafile.write('%s\n' % listitem)
datafile.close()

with open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/RESULT/3_MPC-Data_RMSE_TR1.txt", "w") as datafile:  
    for listitem in Data_RMSE_TR1:
        datafile.write('%s\n' % listitem)
datafile.close()

with open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/RESULT/3_MPC-Data_RMSE_TR3.txt", "w") as datafile:  
    for listitem in Data_RMSE_TR3:
        datafile.write('%s\n' % listitem)
datafile.close()

with open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/RESULT/3_MPC-Data_RMSE_TR5.txt", "w") as datafile:  
    for listitem in Data_RMSE_TR5:
        datafile.write('%s\n' % listitem)
datafile.close()

with open("/home/user/Documents/HVAC_rajib/HVAC_MPC/simulation/RESULT/3_MPC-Data_RMSE_TR7.txt", "w") as datafile:  
    for listitem in Data_RMSE_TR7:
        datafile.write('%s\n' % listitem)
datafile.close()



