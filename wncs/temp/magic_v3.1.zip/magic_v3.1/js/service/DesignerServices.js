'use strict';

var designerServices = angular.module('designerServices', []);

designerServices.service('designerService', function() {
	
	
	
	return 
	{
		schemaGeneration : null
	};

});