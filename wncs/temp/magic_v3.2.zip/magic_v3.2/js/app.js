'use strict';

angular.module('DesignersApp', ['designerControllers','componentTypeService','designerServices']);

